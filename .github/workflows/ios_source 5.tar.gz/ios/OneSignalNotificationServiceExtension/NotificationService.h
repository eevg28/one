//
//  NotificationService.h
//  OneSignalNotificationServiceExtension
//
//  Created by Weiyin He on 8/3/17.
//  Copyright © 2017 GoNative.io LLC. All rights reserved.
//

#import <UserNotifications/UserNotifications.h>

@interface NotificationService : UNNotificationServiceExtension

@end
